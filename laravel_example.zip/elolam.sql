-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2019 at 09:46 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elolam`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog_post`
--

CREATE TABLE `blog_post` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kategori` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog_post`
--

INSERT INTO `blog_post` (`id`, `title`, `kategori`, `description`, `created_at`, `updated_at`) VALUES
(8, 'Kiat-Kiat Menghadapi Pencobaan dalam Hidup', '', '“Aku ga sanggup lagi…”\r\nPernahkah kata-kata diatas keluar dari mulut kita? Dalam keadaan yang seperti apa kata-kata itu muncul? Yap, betul. Masa pencobaan. Apa itu pencobaan? Pencobaan bisa dikaitkan dengan 2 hal, yaitu pengujian dan bujukan untuk melakukan dosa.\r\nBagaimana contoh pencobaan yang bersifat pengujian? Seperti yang pernah dialami oleh Abraham yang tertuang dalam kitab Kejadian 22: 1-9. Allah menguji iman Abraham dengan memerintahkannya mengorbankan Ishak, anaknya. Lalu, apa contoh pencobaan yang bersifat bujukan untuk berdosa? Tentu kita sangat hafal dengan cerita Adam dan Hawa yang memakan buah dari pohon pengetahuan yang dilarang oleh Tuhan (Kej 3: 1-5). Ular itu membujuk Hawa untuk memakan buah itu, lalu Hawa memberikan juga buah itu kepada suaminya. Atau mungkin kita juga bisa menyatukan 2 pengertian diatas, bahwa ketika manusia dalam masa pengujian, dia menjadi jemu dan akhirnya jatuh kedalam dosa.\r\nLalu bagaimana cara kita tetap bertahan dalam jalan Tuhan selama masa pencobaan? Hal yang paling utama adalah makin mendekatkan diri kepada Tuhan. Jangan bosan berdoa, jangan bosan membaca dan mendengarkan firman-Nya. Lalu berkumpullah dengan saudara-saudara seiman, dan saling menguatkan satu sama lain. Mengapa semua hal diatas penting? Kita tahu bahwa Tuhan tidak pernah tidur atau meninggalkan umat-Nya. Tetapi Tuhan juga mengajarkan kita untuk bersabar, sampai tiba waktunya untuk Tuhan mengadakan mukjizat. Seperti kisah Abraham, Malaikat Tuhan datang tepat pada saat Abraham akan menyembelih anaknya. Disini kita bisa ambil kesimpulan bahwa sangat benar adanya, kalau pertolongan Tuhan itu akan tepat pada waktunya, asal kita mau bersabar dan berserah kepada-Nya. Dan janganlah lupa bersyukur, bahwa kita bisa sampai di detik ini, masih bisa bangun dan bernafas, merupakan sebagian kecil dari kemurahan Tuhan atas kita. Ingatlah, Dia mampu menciptakan alam semesta, maka Dia, Tuhan Yesus, pasti mampu menolong kita dari masa pencobaan.', '2019-11-10 01:13:33', '2019-11-10 01:13:33');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2019_11_09_074125_create_events_table', 1),
('2019_11_09_095034_create_blog_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog_post`
--
ALTER TABLE `blog_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog_post`
--
ALTER TABLE `blog_post`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
