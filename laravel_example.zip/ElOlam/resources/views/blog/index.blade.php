<!DOCTYPE html>
<html>
<head>
	<title>Berita</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	@include('navbar')
	{{ Session::get('message') }}
	<div class="container header">
    	<h1>Berita</h1>
    </div>
    <div class="container tambahpost">
    	<h6><a href="/blog/create"><i class="fa fa-plus"></i> Tambah Post</a></h6>
    </div>
    @foreach ($blogs as $blog)
    	<div class="container konten">
    		<div class="row">
    			<h2><a href="/blog/{{ $blog->id }}">{{ $blog->title }}</a></h2>
    		</div>

			<div class="row createdat">
				<h6>{{ date('F d, Y', strtotime($blog->created_at)) }}</h6>
			</div>

			<div class="row">
				<p class="overflow ellipsis">{{ $blog->description }}</p>	
			</div>

			<div class="row">
				<button class="btnEdit"><a href="/blog/{{ $blog->id }}/edit">Edit</a></button>
				<form class="" action="/blog/{{ $blog->id }}" method="post">
					<input type="hidden" name="_method" value="delete">
					<input type="hidden" name="_token" value="{{ csrf_token() }}">
					<button class="btnDelete" name="name" type="submit" value="delete">Delete</button>
				</form>
			</div>
			<hr>
		</div>
	@endforeach
    
	{!! $blogs->links() !!}
</body>
</html>