<!DOCTYPE html>
<html>
<head>
	<title>Detail</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	@include('navbar')
	<div class="container header">
    	<h1>{{ $blog->title }}</h1>
    </div>
    <div class="container back">
    	<h6>{{ date('F d, Y', strtotime($blog->created_at)) }}</h6>
    	<p>{{ $blog->description }}</p>
		<br>
		<a href="/blog">Kembali</a>
    </div>
</body>
</html>