<!DOCTYPE html>
<html>
<head>
	<title>Buat Post</title>
</head>
<body>
	@include('navbar')
    <div class="container header">
    	<h1>Tambahkan Postingan Baru</h1>
    </div>
    <div class="container konten">
    	<form class="" action="/blog" method="post">
    		<div class="row">
    			<div class="col-sm-4">
		    		<h5>Judul</h5>
		    	</div>
		    	<div class="col-sm-8">
		    		<input type="text" name="title" value="" placeholder="Title">
					{{ ($errors -> has('title')) ? $errors -> first('title') : '' }}
		    	</div>
    		</div><br>
    				
    		<div class="row">
    			<div class="col-sm-4">
		    		<h5 for="sel1">Kategori</h5>
		    	</div>
		    	<div class="col-sm-8">
					<select class="form-control" id="sel1">
					  <option value="Artikel">Artikel</option>
					  <option value="Ringkasan Khotbah">Ringkasan Khotbah</option>
					  <option value="Pelajaran">Pelajaran</option>
					</select>
		    	</div>
    		</div><br>

    		<div class="row">
    			<div class="col-sm-4">
		    		<h5>Konten</h5>
		    	</div>
		    	<div class="col-sm-8">
		    		<textarea name="description" rows="20" cols="95" placeholder="Write content here"></textarea>
					{{ ($errors -> has('description')) ? $errors -> first('description') : '' }}
		    	</div>
    		</div><br>
			
			<input type="hidden" name="_token" value="{{ csrf_token() }}">
			<button type="submit" class="btnSubmit" value="post">Submit</button>
		</form>
    </div>
</body>
</html>