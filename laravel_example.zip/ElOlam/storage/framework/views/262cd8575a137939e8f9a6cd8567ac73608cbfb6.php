<!DOCTYPE html>
<html>
<head>
	<title>Tentang Kami - GPdI El Olam</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">   
</head>
<body>
	<?php echo $__env->make('navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container header">
    	<h1>Sejarah GPdI El Olam</h1>
    </div>
    <div class="container konten">
    	<div class="row">
    		<div class="col-sm-4">
    			<h6>Gembala</h6>
    			<img src="/images/thumbnail.png" class="gembala"><!-- foto gembala -->
    			<h6>Pdt. Benny Y. Tambuwun</h6>
    		</div>
    		<div class="col-sm-8">
    			<h6>Apa arti El Olam?</h6>
    			<p>
    				El Olam berasal dari dua kata yang berbeda. Kata “El” berasal dari kata “Elohim” yang berarti Allah yang Trinitas dan “Olam” berarti kekal. Jadi, kata “El Olam” berarti “Allah yang Kekal Tetap Melakukan Hal-hal yang Kekal.”
    			</p>
    			<h6>Tahun 1987</h6>
    			<p>
    				Gereja Pantekosta di Indonesia (GPdI) jemaat El Olam dirintis sejak tahun 1986, dengan cara dilaju dari Jawa Timur ke Jakarta, dilakukan perjalanan – pergi-pulang - dengan memakai kereta api. Realisasi pelayanan baru dimulai pada tahun 1987. <br>
    			</p>
    			<p>
    				Pelayanan dimulai di rumah kontrakan keluarga Ishak yang terletak di pinggir kali. Dimana anak mereka yang bernama Leonny menderita sakit, sembuh setelah didoakan selama 2 bulan berturut-turut. Lalu pelayanan dipindahkan lagi di kediaman keluarga Simon Kanatalo yang berada di Jl. O, Palmerah, Jakarta Barat. Pelayanan dipindahkan kemari karena ibu Catherine Kanatalo yang mederita sakit, juga sembuh setelah didoakan. Rumahnya pun dibuka untuk pelayanan. <br>
    			</p>
    			<p>
    				Ditahun ini juga, sekolah minggu pertama dimulai, dengan murid pertama adalah Elsya. Untuk menambah jumlah murid, dipinjam empat orang anak dari keluarga Rudy yang tinggal di kompleks DPR 1, Kebon Jeruk, bersama dengan empat orang anak satu keluarga baru. Pelayanan Sekolah Minggu dimulai di rumah keluarga Silalahi, juga di Palmerah.
    			</p>
    			<h6>Tahun 1988</h6>
    			<p>
    				Pada tahun 1988, sebuah cabang pelayanan GPdI Kebayoran Lama, yang digembalakan Pdt. Paulus Hendrawan, diserahkan kepada GPdI El Olam, terletak di Jl. Kemandoran VIII, Grogol Petamburan, Kebayoran Lama. Dengan ini GPdI El Olam memiliki ibadah hari Minggu. <br>
    			</p>
    			<p>
    				Ibadah berjalan beberapa tahun, hingga rumah itu mereka jual, mereka pindah ke Bogor, sehingga kebaktian harus ditutup. Atas inisiatif Sdri. Wiwid – sekarang ibu Wiwid Simanjutak – dilakukan pendekatan dengan ibu Nyo Ing, di Jl. Karya Baru, Kebayoran Lama, untuk dapat menampung pelayanan. Rumah tersebut direhab dengan cara bekerja sama sehingga mendapatkan tumpangan di ruang tamu.
    			</p>
    			<h6>Tahun 1990-1994</h6>
    			<p>
    				Lokasi pelayanan terus berpindah-pindah. Sepak terjang pelayanan pun telah dialami. Namun Puji Tuhan, mukjizat Tuhan tidak pernah hilang, kemanapun kami pergi. Hingga pada satu hari Kel. Budi menelpon menawarkan ruko di Intercon Plaza F/9 – yang telah tiga tahun ditawarkan untuk disewakan tidak ada yang berminat – saat itu baru teringat ternyata sebelas tahun yang lalu (hitungan mundur sejak saat itu) lokasi Intercon yang sedang dibangun sudah kami doakan. Sejak saat itu didoakan F/17 agar terbeli, Puji Tuhan, dalam waktu dua tahun lunas.
    			</p>
    			<h6>Tahun 1995</h6>
    			<p>
    				Sejak tahun 1995 ibadah berpindah ke Intercon Plaza F/17 hingga sekarang ini – dengan kekayaan mujizat dilakukan oleh Allah yang kekal – sesuai dengan nama-Nya, El Olam, Ia lakukan hinga sekarang ini. Kini jemaat bertumbuh secara rohani, hidup rukun damai, memberi diri melayani Tuhan dan cinta kekudusan. Mari terus kita doakan agar kasih kemurahan Allah yang kekal itu tetap Ia limpahkan bagi GPdI Jemaat El Olam, terpujilah Tuhan kita Yesus Kristus.
    			</p>
    		</div>
    	</div>
    </div>
</body>
</html>