<!DOCTYPE html>
<html>
<head>
	<title>Detail</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<?php echo $__env->make('navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="container header">
    	<h1><?php echo e($blog->title); ?></h1>
    </div>
    <div class="container back">
    	<h6><?php echo e(date('F d, Y', strtotime($blog->created_at))); ?></h6>
    	<p><?php echo e($blog->description); ?></p>
		<br>
		<a href="/blog">Kembali</a>
    </div>
</body>
</html>