<!DOCTYPE html>
<html>
<head>
	<title>Berita</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<?php echo $__env->make('navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo e(Session::get('message')); ?>

	<div class="container header">
    	<h1>Berita</h1>
    </div>
    <div class="container tambahpost">
    	<h6><a href="/blog/create"><i class="fa fa-plus"></i> Tambah Post</a></h6>
    </div>
    <?php foreach($blogs as $blog): ?>
    	<div class="container konten">
    		<div class="row">
    			<h2><a href="/blog/<?php echo e($blog->id); ?>"><?php echo e($blog->title); ?></a></h2>
    		</div>

			<div class="row createdat">
				<h6><?php echo e(date('F d, Y', strtotime($blog->created_at))); ?></h6>
			</div>

			<div class="row">
				<p><?php echo e($blog->description); ?></p>	
			</div>

			<div class="row">
				<button class="btnEdit"><a href="/blog/<?php echo e($blog->id); ?>/edit">Edit</a></button>
				<form class="" action="/blog/<?php echo e($blog->id); ?>" method="post">
					<input type="hidden" name="_method" value="delete">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button class="btnDelete" name="name" type="submit" value="delete">Delete</button>
				</form>
			</div>
			<hr>
		</div>
	<?php endforeach; ?>
    
	<?php echo $blogs->links(); ?>

</body>
</html>