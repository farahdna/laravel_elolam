<!DOCTYPE html>
<html>
<head>
	<title>Buat Jadwal</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Cinzel:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600&display=swap" rel="stylesheet">
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<style type="text/css">
        body{
            background-color: #aec6a6;
        }
    </style>
</head>
<body>
	<nav class="navbar navbar-expand-md">
        <!-- Brand/logo -->
        <a class="navbar-brand" href="#">GPdI El Olam</a>

        <!-- Toggler/collapsibe Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Links -->
        <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="/beranda">Beranda</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/tentang">Tentang Kami</a>
              </li>
              <li class="nav-item dropdown">
              	<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Pelayanan</a>
			    <div class="dropdown-menu">
			    	<a class="dropdown-item" href="/jadwal">Jadwal Pelayanan</a>
			    	<a class="dropdown-item" href="/acara">Acara</a>
			    </div>
              </li>
              <li class="nav-item">
                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Berita</a>
                <div class="dropdown-menu">
			    	<a class="dropdown-item" href="/artikel">Artikel</a>
			    	<a class="dropdown-item" href="/warta">Warta Jemaat</a>
			    	<a class="dropdown-item" href="/pelajaran">Pelajaran</a>
			    </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Galeri</a>
              </li>
            </ul>
        </div>
    </nav>
    <div class="container">
    	<br>
    	<form method="post" action="<?php echo e(url('acara/add')); ?>">
    		@csrf
    		<div class="row">
    			<div class="col-md-4"></div>
    			<div class="form-group col-md-4">
		          <label for="Title">Nama Acara :</label>
		          <input type="text" class="form-control" name="title">
		        </div>
    		</div>
    		<div class="row">
	          	<div class="col-md-4"></div>
		        <div class="form-group col-md-4">
		          <strong> Tanggal Dimulai : </strong>  
		          <input class="date form-control"  type="text" id="startdate" name="startdate">   
		        </div>
	        </div>
	        <div class="row">
	            <div class="col-md-4"></div>
		        <div class="form-group col-md-4">
		          <strong> Tanggal Selesai : </strong>  
		          <input class="date form-control"  type="text" id="enddate" name="enddate">   
		        </div>
	        </div>
	        <div class="row">
	            <div class="col-md-4"></div>
	            <div class="form-group col-md-4">
	              <button type="submit" class="btn btn-success">Tambah</button>
	            </div>
	        </div>
    	</form>
    </div>
    <script type="text/javascript">  
        $('#startdate').datepicker({ 
            autoclose: true,   
            format: 'yyyy-mm-dd'  
         });
         $('#enddate').datepicker({ 
            autoclose: true,   
            format: 'yyyy-mm-dd'
         }); 
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>